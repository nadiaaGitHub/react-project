
const catogories=[

    {
        id:1,
        productPic:"https://amberstore.pk/uploads/659679329-electronic.png",
        productName:"ELECTRONICS"
    },
    {
        id:2,
        productPic:"https://amberstore.pk/uploads/191902606-camera.png",
        productName:"CAMERA"
    },
    {
        id:3,
        productPic:"https://amberstore.pk/uploads/547865530-camera-acce-png.png",
        productName:"CAMERA ACCESSORIES"
    },
    {
        id:4,
        productPic:"https://amberstore.pk/uploads/881352424-fashion.png",
        productName:"FASHION"
    },
    {
        id:5,
        productPic:"https://amberstore.pk/uploads/960741118-web-logo.jpg",
        productName:"HIGH END COSMETICS"
    },
    {
        id:6,
        productPic:"https://amberstore.pk/uploads/629326856-clothes.png",
        productName:"CLOTHES"
    },
]

export default catogories;