const product = [
    {
        id:1,
        productPic:"https://amberstore.pk/uploads/680677986-51nfv1vbdjl._ac_sl1500_.jpg",
        productTitle:"LUPPEE kids whale potty",
        productPrice:2950,
        productDeletedPrice:7000
    },
    {
        id:2,
        productPic:"https://amberstore.pk/uploads/655137385-61vnplcjbts._ac_sl1001_.jpg",
        productTitle:"Beduan Air Blow Gun Kit",
        productPrice:1750,
        productDeletedPrice:4000
    },
    {
        id:3,
        productPic:"https://amberstore.pk/uploads/446535873-loratap-4th-generation-wifi-roller-shutter-curtain-switch-for-electric-blind-google-home-alexa-smart-life.png_.webp",
        productTitle:"Lora Tap 2X/Blind SWitch Conne",
        productPrice:2450,
        productDeletedPrice:95000
    },
    {
        id:4,
        productPic:"https://amberstore.pk/uploads/144994970-h5a0c8840f90844c9bd95e3f262a104350.jpg",
        productTitle:"LH-98 Antireversible Lense Hood For",
        productPrice:1350,
        productDeletedPrice:2900
    },
    {
        id:5,
        productPic:"https://amberstore.pk/uploads/151336681-71xdjhavnbl._ac_sl1500_.jpg",
        productTitle:"Anker wireless Charger Power",
        productPrice:7450,
        productDeletedPrice:24000
    },
    {
        id:6,
        productPic:"https://amberstore.pk/uploads/522469417-61k0amqsfxs._ac_sl1500_.jpg",
        productTitle:"EZVIZ LC3 (4MP) smart outdoor",
        productPrice:1650,
        productDeletedPrice:80000
    },
    {
        id:7,
        productPic:"https://amberstore.pk/uploads/788358433-b08c56vwk9_3.webp",
        productTitle:"Musical toy for baby Tinoteen",
        productPrice:2950,
        productDeletedPrice:3000
    },
    {
        id:8,
        productPic:"https://amberstore.pk/uploads/619245703-71whqkdkqll._ac_sl1500_.jpg",
        productTitle:"LED Reading lamp Holder WW",
        productPrice:1750,
        productDeletedPrice:3000
    },
    {
        id:9,
        productPic:"https://amberstore.pk/uploads/680677986-51nfv1vbdjl._ac_sl1500_.jpg",
        productTitle:"LUPPEE kids whale potty",
        productPrice:2950,
        productDeletedPrice:7000
    },
    {
        id:10,
        productPic:"https://amberstore.pk/uploads/680677986-51nfv1vbdjl._ac_sl1500_.jpg",
        productTitle:"LUPPEE kids whale potty",
        productPrice:2950,
        productDeletedPrice:7000
    },
    {
        id:11,
        productPic:"https://amberstore.pk/uploads/680677986-51nfv1vbdjl._ac_sl1500_.jpg",
        productTitle:"LUPPEE kids whale potty",
        productPrice:2950,
        productDeletedPrice:7000
    },
    {
        id:12,
        productPic:"https://amberstore.pk/uploads/680677986-51nfv1vbdjl._ac_sl1500_.jpg",
        productTitle:"LUPPEE kids whale potty",
        productPrice:2950,
        productDeletedPrice:7000
    },
    {
        id:13,
        productPic:"https://amberstore.pk/uploads/680677986-51nfv1vbdjl._ac_sl1500_.jpg",
        productTitle:"LUPPEE kids whale potty",
        productPrice:2950,
        productDeletedPrice:7000
    },
    {
        id:14,
        productPic:"https://amberstore.pk/uploads/680677986-51nfv1vbdjl._ac_sl1500_.jpg",
        productTitle:"LUPPEE kids whale potty",
        productPrice:2950,
        productDeletedPrice:7000
    },
    {
        id:115,
        productPic:"https://amberstore.pk/uploads/680677986-51nfv1vbdjl._ac_sl1500_.jpg",
        productTitle:"LUPPEE kids whale potty",
        productPrice:2950,
        productDeletedPrice:7000
    },
    {
        id:16,
        productPic:"https://amberstore.pk/uploads/680677986-51nfv1vbdjl._ac_sl1500_.jpg",
        productTitle:"LUPPEE kids whale potty",
        productPrice:2950,
        productDeletedPrice:7000
    },
    {
        id:17,
        productPic:"https://amberstore.pk/uploads/680677986-51nfv1vbdjl._ac_sl1500_.jpg",
        productTitle:"LUPPEE kids whale potty",
        productPrice:2950,
        productDeletedPrice:7000
    },
    {
        id:18,
        productPic:"https://amberstore.pk/uploads/680677986-51nfv1vbdjl._ac_sl1500_.jpg",
        productTitle:"LUPPEE kids whale potty",
        productPrice:2950,
        productDeletedPrice:7000
    },
];

export default product;